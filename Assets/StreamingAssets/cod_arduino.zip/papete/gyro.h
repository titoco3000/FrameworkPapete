/*
    Baseado em:

        MPU6050 Triple Axis Gyroscope & Accelerometer. Pitch & Roll Accelerometer Example.
        Read more: http://www.jarzebski.pl/arduino/czujniki-i-sensory/3-osiowy-zyroskop-i-akcelerometr-mpu6050.html
        GIT: https://github.com/jarzebski/Arduino-MPU6050
        Web: http://www.jarzebski.pl
        (c) 2014 by Korneliusz Jarzebski

    Por: Tito Guidotti
*/

#include <Wire.h>
#include "MPU6050.h"

MPU6050 mpu;

void IniciarGyro()
{
    while (!mpu.begin(MPU6050_SCALE_2000DPS, MPU6050_RANGE_2G))
    {
        Serial.println("Could not find a valid MPU6050 sensor, check wiring!");
        delay(500);
    }
}

String MensagemGyro()
{
    // Read normalized values
    Vector normAccel = mpu.readNormalizeAccel();

    // Calculate Pitch & Roll
    // int pitch = -(atan2(normAccel.XAxis, sqrt(normAccel.YAxis * normAccel.YAxis + normAccel.ZAxis * normAccel.ZAxis)) * 180.0) / M_PI;
    // int roll = (atan2(normAccel.YAxis, normAccel.ZAxis) * 180.0) / M_PI;

    return String(normAccel.XAxis, 6) + ";" + String(normAccel.YAxis, 6) + ";" + String(normAccel.ZAxis, 6);
}
